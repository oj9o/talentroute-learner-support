# TalentRoute — early learner-support triage

MAAI7101 Intermediate: real OULAD data, classification and engagement outlier detection feeding a staff-time-constrained priority list. The current evidence supports classifier-only as the simpler provisional reference. Targeting is measured; intervention effectiveness is not.

## Run from an extracted package

Install `uv` and `just`. Python 3.14 is provisioned by `uv sync`.

```sh
just install
just test
just pipeline
just app 150
just app 600
```

`just test` runs standalone tests and skips evidence-dependent checks until outputs exist. `just run-baseline` fits and evaluates the connected baseline policies. `just pipeline` verifies supplied data (or downloads if absent), prepares, fits, evaluates, runs exploratory analyses/diagnostics, generates ten figures and the report/interface, then tests regenerated evidence. `just clean` removes all generated output, processed data and interface files, retaining raw downloads and historical evidence/ records. No GPU, credentials or LLM API is required.

Open `review/index.html` directly in a browser to inspect the saved evidence offline. Its local CSS/JavaScript and the sibling outputs/docs folders must stay with it. `review/report.html` is a readable view of the canonical `docs/baseline_report.md`. `just review` regenerates both. CLI worklists use synthetic case references and are excluded from submission.

## Evidence and configuration

Read docs/project_definition.md for scope, commitments and acceptance criteria; docs/baseline_report.md for generated methods/results; docs/data_dictionary.md for feature semantics. Supporting findings/register and CSV evidence document exploratory checks. configs/policy.json contains costs, budget, timing assumptions and seeds. Reserved 2014J outcomes never select models. scripts/eda.py is the just eda entry point.

## Data access

Kuzilek, Hlosta & Zdrahal (2015), OULAD, UCI, CC BY 4.0: https://doi.org/10.24432/C5KK69. The submission includes the seven original public CSVs, compressed once by the outer submission ZIP, to avoid slow upstream downloads. `just download-data` verifies each CSV against configured hashes derived from the checksum-pinned official archive. If CSVs are absent, it downloads/verifies/extracts the official archive. An offline alternative is placing that archive at `data/raw/oulad.zip`. Generated student-level predictions and private instructor feedback are excluded. Attribution is retained; bundled data are the publicly released anonymised OULAD records.

## Verification

Recent Mac analytical runs completed in about one minute with tests passed; installation/network excluded. Exact timing is recorded below.

Current-run timing/platform/tests: outputs/current_pipeline_verification.json. Installation/network time is separate. The interface explains the evidence; it does not replace runnable code/report.

Historical Mac/Python3.14.7 and Ubuntu24.04 ARM VM/Python3.14.10 runs passed 21 tests each. Those records predate current source and live in evidence/platform-validation-2026-10-31/. VM is not container verification. Small tree-model platform differences are recorded; regenerated reports consistently use local results.

## Code-only audit package
The separately named Main_Code ZIP excludes data, generated outputs and the interface build. It contains the same source/configuration/lockfile as the full package. Run `just download-data` before `just pipeline`; the upstream download can take over 30 minutes on a slow connection and is not part of the analytical runtime. For offline use, use the full package or place the verified official archive at data/raw/oulad.zip. Report images become available after regeneration.

`just verify` reconciles prepared partitions, predictor exclusions, validation-only predictions, saved coverage and staff costs. outputs/submission_claim_checks.json records each check; missed_case_profile.csv reports aggregate missed cases. These checks validate declared artifacts, not causal benefit.
